import asyncio
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
import time
from pathlib import Path
from urllib.parse import parse_qsl

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
    LabeledPrice, Message, PreCheckoutQuery, WebAppInfo,
)

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.getenv("ADMIN_ID", "7170883398"))
BOT_USERNAME = os.getenv("BOT_USERNAME", "").lstrip("@")
MINI_APP_URL = os.environ["MINI_APP_URL"].rstrip("/")
WEB_HOST = os.getenv("WEB_HOST", "0.0.0.0")
WEB_PORT = int(os.getenv("WEB_PORT", "8080"))
DB_PATH = os.getenv("DB_PATH", "hotgold.sqlite3")
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

PACKAGES = {
    "HG-1000": {"gold": 1000, "stars": 999},
    "HG-3000": {"gold": 3000, "stars": 1599},
    "HG-6000": {"gold": 6000, "stars": 2999},
    "HG-9000": {"gold": 9000, "stars": 3999},
    "HG-16000": {"gold": 16000, "stars": 5999},
}
GAME_ID_PATTERN = re.compile(r"[0-9]{8,9}\Z")
DELIVERY_NOTICE = (
    "Gold будет зачислена на аккаунт не сразу, но в течение 78 часов. "
    "Если после истечения этого срока Gold не поступит, обратитесь в поддержку."
)

dp = Dispatcher(storage=MemoryStorage())
bot = Bot(BOT_TOKEN)


class Order(StatesGroup):
    game_id = State()
    confirmation = State()


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS deals (
            id TEXT PRIMARY KEY,
            creator_id INTEGER NOT NULL,
            creator_username TEXT,
            creator_name TEXT,
            mode TEXT NOT NULL CHECK(mode IN ('sell','buy')),
            amount INTEGER NOT NULL,
            title TEXT NOT NULL,
            photo TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            buyer_id INTEGER,
            buyer_username TEXT,
            seller_id INTEGER,
            seller_username TEXT,
            created_at INTEGER NOT NULL,
            paid_at INTEGER,
            code TEXT,
            confirmed_at INTEGER
        )
        """)
        con.execute("""
        CREATE TABLE IF NOT EXISTS processed_payments (
            charge_id TEXT PRIMARY KEY,
            deal_id TEXT NOT NULL,
            user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            created_at INTEGER NOT NULL
        )
        """)


def fmt(number: int) -> str:
    return f"{number:,}".replace(",", " ")


def packages_keyboard():
    rows = [[InlineKeyboardButton(
        text=f"{fmt(p['gold'])} Gold — {fmt(p['stars'])} ⭐",
        callback_data=f"package:{code}",
    )] for code, p in PACKAGES.items()]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def miniapp_keyboard(deal_id=None):
    url = MINI_APP_URL
    if deal_id:
        url = f"{url}?deal={deal_id}"
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Открыть HOTGOLD", web_app=WebAppInfo(url=url))
    ]])


def validate_webapp_init_data(init_data: str):
    if not init_data:
        raise web.HTTPUnauthorized(text="Нет данных авторизации Telegram")
    values = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = values.pop("hash", None)
    if not received_hash:
        raise web.HTTPUnauthorized(text="Некорректная авторизация")
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(values.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise web.HTTPUnauthorized(text="Не удалось проверить Telegram-пользователя")
    auth_date = int(values.get("auth_date", "0"))
    if time.time() - auth_date > 86400:
        raise web.HTTPUnauthorized(text="Срок авторизации истёк. Перезапустите Mini App")
    try:
        user = json.loads(values["user"])
    except Exception:
        raise web.HTTPUnauthorized(text="Не удалось прочитать профиль Telegram")
    return user


@web.middleware
async def api_errors(request, handler):
    try:
        return await handler(request)
    except web.HTTPException:
        raise
    except Exception:
        logging.exception("Ошибка Mini App API")
        return web.json_response({"ok": False, "error": "Внутренняя ошибка сервера"}, status=500)


def get_user(request):
    return request["tg_user"]


@web.middleware
async def telegram_auth_middleware(request, handler):
    if request.path.startswith("/api/"):
        init_data = request.headers.get("X-Telegram-Init-Data", "")
        request["tg_user"] = validate_webapp_init_data(init_data)
    return await handler(request)


async def index(request):
    return web.FileResponse(Path("webapp/index.html"))


async def create_deal(request):
    user = get_user(request)
    data = await request.json()
    mode = data.get("mode")
    title = str(data.get("title", "")).strip()
    amount = data.get("amount")
    photo_data = data.get("photo", "")
    if mode not in ("sell", "buy"):
        return web.json_response({"ok": False, "error": "Выберите «Купить» или «Продать»"}, status=400)
    if not isinstance(amount, int) or isinstance(amount, bool) or not 100 <= amount <= 100000:
        return web.json_response({"ok": False, "error": "Сумма должна быть от 100 до 100 000 Stars"}, status=400)
    if not title or len(title) > 70 or not re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9 ]+", title):
        return web.json_response({"ok": False, "error": "Название: только буквы, цифры и пробелы (до 70 символов)"}, status=400)
    match = re.fullmatch(r"data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)", photo_data)
    if not match:
        return web.json_response({"ok": False, "error": "Прикрепите фото PNG, JPG или WEBP"}, status=400)
    import base64
    raw = base64.b64decode(match.group(2), validate=True)
    if not raw or len(raw) > 5 * 1024 * 1024:
        return web.json_response({"ok": False, "error": "Фото должно быть не больше 5 МБ"}, status=400)
    ext = {"jpeg": ".jpg", "png": ".png", "webp": ".webp"}[match.group(1)]
    deal_id = secrets.token_urlsafe(8).replace("-", "").replace("_", "")[:12]
    photo_name = f"{deal_id}{ext}"
    (UPLOAD_DIR / photo_name).write_bytes(raw)
    username = user.get("username")
    name = user.get("first_name", "Пользователь")
    with db() as con:
        con.execute("""INSERT INTO deals
        (id, creator_id, creator_username, creator_name, mode, amount, title, photo, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (deal_id, user["id"], username, name, mode, amount, title, photo_name, int(time.time())))
    share = f"https://t.me/{BOT_USERNAME}?start=deal_{deal_id}" if BOT_USERNAME else ""
    return web.json_response({"ok": True, "deal_id": deal_id, "share_url": share})


def deal_dict(row):
    return {
        "id": row["id"], "mode": row["mode"], "amount": row["amount"],
        "title": row["title"], "photo_url": f"/uploads/{row['photo']}",
        "status": row["status"], "creator_username": row["creator_username"],
        "creator_name": row["creator_name"], "buyer_id": row["buyer_id"],
        "seller_id": row["seller_id"],
    }


async def get_deal(request):
    deal_id = request.match_info["deal_id"]
    user = get_user(request)
    with db() as con:
        row = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
    if not row:
        return web.json_response({"ok": False, "error": "Сделка не найдена"}, status=404)
    return web.json_response({"ok": True, "deal": deal_dict(row), "viewer_id": user["id"]})


async def join_deal(request):
    deal_id = request.match_info["deal_id"]
    user = get_user(request)
    with db() as con:
        row = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
        if not row:
            return web.json_response({"ok": False, "error": "Сделка не найдена"}, status=404)
        if row["status"] != "open":
            return web.json_response({"ok": False, "error": "К сделке уже нельзя присоединиться"}, status=400)
        if user["id"] == row["creator_id"]:
            return web.json_response({"ok": True, "role": "creator", "deal": deal_dict(row)})
        if row["mode"] == "sell":
            con.execute("UPDATE deals SET buyer_id=?, buyer_username=? WHERE id=? AND buyer_id IS NULL",
                        (user["id"], user.get("username"), deal_id))
            role = "buyer"
        else:
            con.execute("UPDATE deals SET seller_id=?, seller_username=? WHERE id=? AND seller_id IS NULL",
                        (user["id"], user.get("username"), deal_id))
            role = "seller"
        updated = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
    return web.json_response({"ok": True, "role": role, "deal": deal_dict(updated)})


async def create_invoice(request):
    deal_id = request.match_info["deal_id"]
    user = get_user(request)
    with db() as con:
        row = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
    if not row or row["status"] != "open":
        return web.json_response({"ok": False, "error": "Сделка недоступна"}, status=400)
    if row["mode"] == "sell":
        expected_payer = row["buyer_id"]
    else:
        expected_payer = row["creator_id"]
    if expected_payer != user["id"]:
        return web.json_response({"ok": False, "error": "Оплатить может только покупатель"}, status=403)
    payload = f"deal|{deal_id}"
    link = await bot.create_invoice_link(
        title=f"Оплата: {row['title'][:32]}",
        description=f"Оплата сделки HOTGOLD #{deal_id}",
        payload=payload,
        currency="XTR",
        prices=[LabeledPrice(label=row["title"][:32], amount=row["amount"])],
    )
    return web.json_response({"ok": True, "invoice_url": link})


async def confirm_deal(request):
    deal_id = request.match_info["deal_id"]
    user = get_user(request)
    with db() as con:
        row = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
        if not row:
            return web.json_response({"ok": False, "error": "Сделка не найдена"}, status=404)
        buyer_id = row["buyer_id"] if row["mode"] == "sell" else row["creator_id"]
        if user["id"] != buyer_id:
            return web.json_response({"ok": False, "error": "Подтвердить получение может только покупатель"}, status=403)
        if row["status"] != "paid":
            return web.json_response({"ok": False, "error": "Сделка ещё не оплачена или уже закрыта"}, status=400)
        con.execute("UPDATE deals SET status='completed', confirmed_at=? WHERE id=?",
                    (int(time.time()), deal_id))
    await bot.send_message(ADMIN_ID, f"✅ Покупатель подтвердил получение по сделке #{deal_id}.")
    return web.json_response({"ok": True})


async def health(request):
    return web.json_response({"ok": True, "service": "HOTGOLD Mini App"})


@dp.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    args = ""
    if message.text:
        parts = message.text.split(maxsplit=1)
        if len(parts) > 1:
            args = parts[1].strip()
    if args.startswith("deal_"):
        deal_id = args[5:]
        await message.answer(
            "Вам отправили ссылку на сделку HOTGOLD. Откройте карточку сделки:",
            reply_markup=miniapp_keyboard(deal_id),
        )
        return
    await message.answer(
        "Здравствуйте! Выберите пакет Gold или откройте гарант HOTGOLD.",
        reply_markup=packages_keyboard(),
    )
    await message.answer("Открыть мини-приложение гаранта:", reply_markup=miniapp_keyboard())


@dp.callback_query(F.data.startswith("package:"))
async def choose_package(callback: CallbackQuery, state: FSMContext):
    code = callback.data.split(":", 1)[1]
    package = PACKAGES.get(code)
    if package is None:
        await callback.answer("Пакет не найден. Нажмите /start.", show_alert=True)
        return
    await state.clear()
    await state.update_data(code=code)
    await state.set_state(Order.game_id)
    await callback.answer(f"{fmt(package['gold'])} Gold — {fmt(package['stars'])} Stars ⭐", show_alert=True)
    if callback.message:
        await callback.message.answer(
            f"Вы выбрали пакет: {fmt(package['gold'])} Gold.\n\n"
            "Отправьте игровой ID (только 8 или 9 цифр)."
        )


@dp.message(Order.game_id, F.text)
async def get_game_id(message: Message, state: FSMContext):
    game_id = message.text.strip()
    if GAME_ID_PATTERN.fullmatch(game_id) is None:
        await message.answer("<b>ID введен неверно</b>", parse_mode=ParseMode.HTML)
        return
    await state.update_data(game_id=game_id)
    await state.set_state(Order.confirmation)
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Далее", callback_data="order:next")
    ]])
    await message.answer(DELIVERY_NOTICE, reply_markup=keyboard)


@dp.callback_query(F.data == "order:next")
async def show_order(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    package = PACKAGES.get(data.get("code"))
    game_id = data.get("game_id")
    if not package or not game_id or GAME_ID_PATTERN.fullmatch(game_id) is None:
        await callback.answer("Заказ не найден. Начните заново: /start", show_alert=True)
        return
    keyboard = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=f"Оплатить {fmt(package['stars'])} ⭐", callback_data="pay")
    ]])
    await callback.answer()
    if callback.message:
        await callback.message.answer(
            f"Ваш заказ:\nGold: {fmt(package['gold'])}\nИгровой ID: {game_id}\n"
            f"К оплате: {fmt(package['stars'])} Stars ⭐",
            reply_markup=keyboard,
        )


@dp.callback_query(F.data == "pay")
async def pay_gold(callback: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    package = PACKAGES.get(data.get("code"))
    game_id = data.get("game_id")
    if not package or not game_id or GAME_ID_PATTERN.fullmatch(game_id) is None:
        await callback.answer("Начните заново: /start", show_alert=True)
        return
    if callback.message:
        await callback.message.answer_invoice(
            title=f"{fmt(package['gold'])} Gold",
            description=f"Игровая валюта Gold для ID {game_id}",
            payload=f"{data['code']}|{game_id}",
            currency="XTR",
            prices=[LabeledPrice(label=f"{fmt(package['gold'])} Gold", amount=package["stars"])],
        )
    await callback.answer()


@dp.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    parts = query.invoice_payload.split("|", 1)
    valid = False
    if len(parts) == 2:
        code, game_id = parts
        package = PACKAGES.get(code)
        valid = bool(package and GAME_ID_PATTERN.fullmatch(game_id)
                     and query.currency == "XTR" and package["stars"] == query.total_amount)
    await query.answer(ok=valid, error_message=None if valid else "Ошибка заказа. Начните заново: /start")


@dp.message(F.successful_payment)
async def paid(message: Message, state: FSMContext, bot: Bot):
    payment = message.successful_payment
    if payment.invoice_payload.startswith("deal|"):
        deal_id = payment.invoice_payload.split("|", 1)[1]
        buyer = message.from_user
        code = f"{secrets.randbelow(1_000_000):06d}"
        with db() as con:
            row = con.execute("SELECT * FROM deals WHERE id=?", (deal_id,)).fetchone()
            if not row:
                await message.answer("Платёж получен, но сделка не найдена. Напишите менеджеру.")
                await bot.send_message(ADMIN_ID, f"⚠️ Платёж по неизвестной сделке #{deal_id}.")
                return
            expected = row["buyer_id"] if row["mode"] == "sell" else row["creator_id"]
            if buyer.id != expected or payment.currency != "XTR" or payment.total_amount != row["amount"]:
                await message.answer("Платёж получен, но требуется ручная проверка менеджера.")
                await bot.send_message(ADMIN_ID, f"⚠️ Проверьте платёж по сделке #{deal_id}.")
                return
            existing = con.execute("SELECT 1 FROM processed_payments WHERE charge_id=?",
                                   (payment.telegram_payment_charge_id,)).fetchone()
            if existing:
                return
            con.execute("INSERT INTO processed_payments VALUES (?, ?, ?, ?, ?)",
                        (payment.telegram_payment_charge_id, deal_id, buyer.id,
                         payment.total_amount, int(time.time())))
            con.execute("UPDATE deals SET status='paid', paid_at=?, code=? WHERE id=? AND status='open'",
                        (int(time.time()), code, deal_id))
            seller_id = row["creator_id"] if row["mode"] == "sell" else row["seller_id"]
            seller_username = row["creator_username"] if row["mode"] == "sell" else row["seller_username"]
        await message.answer(
            f"Оплата получена! ✅\nКод сделки: <code>{code}</code>\n"
            "Передайте этот код менеджеру при получении товара. "
            "После получения подтвердите сделку в Mini App.",
            parse_mode=ParseMode.HTML,
        )
        await bot.send_message(
            ADMIN_ID,
            f"💰 ОПЛАЧЕНА СДЕЛКА HOTGOLD\n"
            f"Сделка: #{deal_id}\nСумма: {fmt(payment.total_amount)} ⭐\n"
            f"Плательщик: @{buyer.username or 'без username'} (ID {buyer.id})\n"
            f"Код: {code}\nПродавец: @{seller_username or 'без username'}",
        )
        if seller_id:
            try:
                await bot.send_message(
                    seller_id,
                    f"Оплата по сделке #{deal_id} получена. У вас есть 24 часа, чтобы передать товар менеджеру. "
                    "Не передавайте товар напрямую покупателю.",
                )
            except Exception:
                logging.warning("Не удалось отправить сообщение продавцу %s", seller_id)
        return

    parts = payment.invoice_payload.split("|", 1)
    if len(parts) != 2:
        await message.answer("Платёж получен, но данные заказа нужно проверить через поддержку.")
        return
    code, game_id = parts
    package = PACKAGES.get(code)
    if package is None:
        await message.answer("Платёж получен, но пакет не распознан. Обратитесь в поддержку.")
        return
    await state.clear()
    await message.answer(
        f"Оплата прошла успешно ✅\n{fmt(package['gold'])} Gold будут отправлены на ID {game_id}.\n"
        "Спасибо за покупку! Чтобы сделать новый заказ, нажмите /start."
    )
    buyer = message.from_user
    await bot.send_message(
        ADMIN_ID,
        f"💰 Новый оплаченный заказ\nGold: {fmt(package['gold'])}\n"
        f"Stars: {fmt(package['stars'])}\nИгровой ID: {game_id}\n"
        f"Покупатель: {buyer.full_name} (@{buyer.username}, id {buyer.id})\n"
        f"charge_id: {payment.telegram_payment_charge_id}",
    )


async def on_startup(app):
    init_db()
    logging.info("HOTGOLD web server started")


def create_app():
    app = web.Application(middlewares=[api_errors, telegram_auth_middleware])
    app.router.add_get("/", index)
    app.router.add_get("/health", health)
    app.router.add_static("/uploads/", str(UPLOAD_DIR.resolve()), show_index=False)
    app.router.add_post("/api/deals", create_deal)
    app.router.add_get("/api/deals/{deal_id}", get_deal)
    app.router.add_post("/api/deals/{deal_id}/join", join_deal)
    app.router.add_post("/api/deals/{deal_id}/invoice", create_invoice)
    app.router.add_post("/api/deals/{deal_id}/confirm", confirm_deal)
    app.on_startup.append(on_startup)
    return app


async def main():
    logging.basicConfig(level=logging.INFO)
    init_db()
    runner = web.AppRunner(create_app())
    await runner.setup()
    site = web.TCPSite(runner, WEB_HOST, WEB_PORT)
    await site.start()
    logging.info("HOTGOLD Mini App server listening on %s:%s", WEB_HOST, WEB_PORT)
    try:
        await dp.start_polling(bot)
    finally:
        await runner.cleanup()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
